INDONESIA LIFE — PROYEK APK ANDROID

Isi proyek ini adalah pembungkus Android WebView untuk game HTML offline.
Ini BELUM berupa file APK yang siap dipasang.

Membuat APK:
1. Buka folder IndonesiaLifeAPKProject di Android Studio.
2. Tunggu Gradle Sync selesai dan pasang Android SDK Platform 35 jika diminta.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug akan muncul di:
   app/build/outputs/apk/debug/app-debug.apk

Persyaratan: Android Studio + Android SDK + koneksi internet saat Gradle mengunduh plugin pertama kali.
Minimum Android yang ditargetkan: Android 6.0 (API 23).
Game dimuat dari assets lokal, jadi gameplay tidak membutuhkan internet.
